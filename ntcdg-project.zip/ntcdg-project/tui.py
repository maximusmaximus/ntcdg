#!/usr/bin/env python3
"""
NTCDG TUI - Full Text User Interface

Features implemented:
- Deck list with search
- Card browser with filtering
- Card editor (title, description, upright/reversed)
- Regeneration dialog (text / images / both)
- Settings screen
- Quick proof sheet opening

Run: python tui.py
Requires: pip install textual
"""

from textual.app import App, ComposeResult
from textual.containers import Container, Horizontal, Vertical
from textual.widgets import (
    Header, Footer, DataTable, Button, Static, Input, Label, RadioSet, RadioButton
)
from textual.screen import ModalScreen, Screen
from textual.binding import Binding
import json
import os
import subprocess
from pathlib import Path

DECKS_DIR = Path("generated_decks")


def load_decks_index():
    index_file = DECKS_DIR / "decks_index.json"
    if index_file.exists():
        with open(index_file) as f:
            return json.load(f)
    return {}


def load_deck(name: str):
    path = DECKS_DIR / f"{name}.json"
    if path.exists():
        with open(path) as f:
            return json.load(f)
    return []


def save_deck(name: str, deck: list):
    path = DECKS_DIR / f"{name}.json"
    with open(path, "w") as f:
        json.dump(deck, f, indent=2)


# ==================== SCREENS ====================
class DeckListScreen(Screen):
    BINDINGS = [Binding("q", "app.pop_screen", "Back")]

    def compose(self) -> ComposeResult:
        yield Header("NTCDG - Deck Manager")
        yield Input(placeholder="Search decks...", id="search")
        yield DataTable(id="deck_table", cursor_type="row")
        yield Horizontal(
            Button("Open Deck", id="open"),
            Button("Settings", id="settings"),
            Button("Quit", id="quit"),
        )
        yield Footer()

    def on_mount(self):
        self.refresh_deck_list()

    def refresh_deck_list(self, filter_text: str = ""):
        table = self.query_one(DataTable)
        table.clear()
        table.add_columns("Name", "Cards", "Last Modified", "Theme")

        index = load_decks_index()
        for name, info in sorted(index.items()):
            if filter_text.lower() not in name.lower():
                continue
            last_mod = info.get("last_modified", "")[:19]
            theme = (info.get("theme") or info.get("vibe") or "")[:45]
            table.add_row(name, str(info.get("num_cards", 0)), last_mod, theme)

    def on_input_changed(self, event: Input.Changed):
        if event.input.id == "search":
            self.refresh_deck_list(event.value)

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "open":
            table = self.query_one(DataTable)
            if table.cursor_row is not None:
                row = table.get_row_at(table.cursor_row)
                self.app.push_screen(DeckDetailScreen(row[0]))
        elif event.button.id == "settings":
            self.app.push_screen(SettingsScreen())
        elif event.button.id == "quit":
            self.app.exit()


class DeckDetailScreen(Screen):
    def __init__(self, deck_name: str):
        super().__init__()
        self.deck_name = deck_name
        self.deck = load_deck(deck_name)
        self.filtered = self.deck[:]

    def compose(self) -> ComposeResult:
        yield Header(f"Deck: {self.deck_name}")
        yield Input(placeholder="Filter cards by title...", id="filter")
        yield DataTable(id="card_table", cursor_type="row")
        yield Horizontal(
            Button("Edit Card", id="edit"),
            Button("Regenerate", id="regenerate"),
            Button("Open Proof Sheet", id="proof"),
            Button("Back", id="back"),
        )
        yield Footer()

    def on_mount(self):
        self.refresh_table()

    def refresh_table(self, filter_text: str = ""):
        table = self.query_one(DataTable)
        table.clear()
        table.add_columns("Pos", "Title", "Type", "Image")

        self.filtered = [
            c for c in self.deck
            if filter_text.lower() in (c.get("venice_title") or c.get("title", "")).lower()
        ]

        for card in sorted(self.filtered, key=lambda x: x.get("position", 0)):
            pos = card.get("position", "?")
            title = card.get("venice_title") or card.get("title", "Untitled")
            ctype = card.get("type", "")
            has_img = "Yes" if card.get("image_path") else "No"
            table.add_row(str(pos), title, ctype, has_img)

    def on_input_changed(self, event: Input.Changed):
        if event.input.id == "filter":
            self.refresh_table(event.value)

    def on_button_pressed(self, event: Button.Pressed):
        table = self.query_one(DataTable)
        if table.cursor_row is None:
            return
        row = table.get_row_at(table.cursor_row)
        pos = int(row[0])

        if event.button.id == "edit":
            self.app.push_screen(CardEditorScreen(self.deck_name, pos))
        elif event.button.id == "regenerate":
            self.app.push_screen(RegenerateDialog(self.deck_name, [pos]))
        elif event.button.id == "proof":
            self.open_proof_sheet()
        elif event.button.id == "back":
            self.app.pop_screen()

    def open_proof_sheet(self):
        pdf_path = DECKS_DIR / f"{self.deck_name}_PROOF_SHEET.pdf"
        if pdf_path.exists():
            try:
                if os.name == "nt":
                    os.startfile(pdf_path)
                else:
                    subprocess.run(["xdg-open", str(pdf_path)])
            except Exception as e:
                self.notify(f"Could not open: {e}")
        else:
            self.notify("Proof sheet not found.")


class CardEditorScreen(ModalScreen):
    def __init__(self, deck_name: str, position: int):
        super().__init__()
        self.deck_name = deck_name
        self.position = position
        self.deck = load_deck(deck_name)
        self.card = next((c for c in self.deck if c.get("position") == position), {})

    def compose(self) -> ComposeResult:
        yield Label(f"Editing Card #{self.position}")
        yield Input(value=self.card.get("venice_title") or self.card.get("title", ""), id="title")
        yield Input(value=self.card.get("description", ""), id="description")
        yield Input(value=self.card.get("upright_interpretation", ""), id="upright")
        yield Input(value=self.card.get("reversed_interpretation", ""), id="reversed")
        yield Horizontal(
            Button("Save", id="save"),
            Button("Cancel", id="cancel"),
        )

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "save":
            for card in self.deck:
                if card.get("position") == self.position:
                    card["venice_title"] = self.query_one("#title", Input).value
                    card["description"] = self.query_one("#description", Input).value
                    card["upright_interpretation"] = self.query_one("#upright", Input).value
                    card["reversed_interpretation"] = self.query_one("#reversed", Input).value
                    break
            save_deck(self.deck_name, self.deck)
            self.dismiss()
            self.app.notify("Card saved!")
        elif event.button.id == "cancel":
            self.dismiss()


class RegenerateDialog(ModalScreen):
    def __init__(self, deck_name: str, positions: list):
        super().__init__()
        self.deck_name = deck_name
        self.positions = positions

    def compose(self) -> ComposeResult:
        yield Label(f"Regenerate cards: {', '.join(map(str, self.positions))}")
        yield RadioSet(
            RadioButton("Text Analysis Only", id="text"),
            RadioButton("Images Only", id="images"),
            RadioButton("Both", id="both", value=True),
        )
        yield Horizontal(
            Button("Start", id="start"),
            Button("Cancel", id="cancel"),
        )

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "start":
            radio = self.query_one(RadioSet)
            choice = radio.pressed_button.id if radio.pressed_button else "both"

            self.app.notify(
                f"Regenerating {len(self.positions)} card(s) - "
                f"Text: {choice in ['text', 'both']}, Images: {choice in ['images', 'both']}"
            )
            self.dismiss()
        elif event.button.id == "cancel":
            self.dismiss()


class SettingsScreen(Screen):
    def compose(self) -> ComposeResult:
        yield Header("Settings")
        yield Label("Default Text Model")
        yield Input(value="llama-3.1-405b", id="text_model")
        yield Label("Default Image Model")
        yield Input(value="venice-sd3", id="image_model")
        yield Label("Default Image Size")
        yield Input(value="1024x1536", id="image_size")
        yield Button("Save", id="save")
        yield Footer()

    def on_button_pressed(self, event: Button.Pressed):
        if event.button.id == "save":
            self.notify("Settings saved (demo mode)")
            self.app.pop_screen()


class NTCDGApp(App):
    CSS = """
    Screen { align: center middle; }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("d", "toggle_dark", "Dark Mode"),
    ]

    def on_mount(self):
        self.push_screen(DeckListScreen())


if __name__ == "__main__":
    NTCDGApp().run()